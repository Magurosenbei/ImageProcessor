
Initialization done in Program::Initialize()
Everything runs within Program::Run()
Shutdown done in Program::Shutdown()

